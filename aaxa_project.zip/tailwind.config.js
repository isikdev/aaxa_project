module.exports = {
    content: [
        './resources/**/*.blade.php',  // Blade шаблоны
        './resources/**/*.js',         // JS файлы
        './resources/**/*.vue',        // Если используешь Vue
    ],
    theme: {
        extend: {},
    },
    plugins: [],
};
